import requests
import threading
import time
import json
from collections import namedtuple

from datetime import datetime

def sendUUID():
        f=open("./data/runuuid.txt", "r")
        content = f.read()
        print(f'\n{datetime.now()}\n----------------------')
        parsed_json = json.loads(content, object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
        for data in parsed_json.fileData:
            URL = "http://192.168.0.23:8001/ResultIdentifier"
            PARAMS = '[{0}]'.format(json.dumps({'runuuid': data.id}))
            requests.post(URL, data=PARAMS)
            print(data.id)
            return


if __name__ == '__main__':
    try:
        while True:
            sendUUID()
            time.sleep(60)
    except KeyboardInterrupt:
        pass
